-- Create admin_roles table if it doesn't exist
CREATE TABLE IF NOT EXISTS admin_roles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_roles ENABLE ROW LEVEL SECURITY;

-- Create policies if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'admin_roles' 
    AND policyname = 'Admins can view admin roles'
  ) THEN
    CREATE POLICY "Admins can view admin roles"
      ON admin_roles
      FOR SELECT
      USING (auth.uid() IN (SELECT id FROM admin_roles));
  END IF;
END
$$;

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS is_admin(uuid);

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_roles 
    WHERE id = user_id
  );
END;
$$ language plpgsql SECURITY DEFINER;